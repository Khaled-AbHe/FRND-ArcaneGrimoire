import {
  IsString,
  IsOptional,
  IsBoolean,
  IsArray,
  IsEnum,
  IsInt,
  Min,
  Max,
  ValidateNested,
  MinLength,
  MaxLength,
} from 'class-validator';
import { Type } from 'class-transformer';
import { DmgDiceDto } from './dmg-dice.dto';
import { UpcastDiceDto } from './upcast.dice.dto';
import { CantripScalingDto } from './cantrip-scaling.dto';
import { SpellType } from '../enums/spell-type.enum';
import { SpellLevel } from '../enums/spell-level.enum';
import { MagicSchool } from '../enums/magic-school.enum';
import { SaveAbility } from '../enums/save-ability.enum';
import { DiceType } from '../enums/dice-type.enum';
import { OutputType } from '../enums/output-type.enum';
import { AttackType } from '../enums/attack-type.enum';

export class CreateSpellDto {
  @IsString()
  @MinLength(1)
  @MaxLength(128)
  name: string;

  @IsOptional()
  @IsEnum(SpellLevel)
  level?: SpellLevel;

  @IsOptional()
  @IsEnum(MagicSchool)
  school?: MagicSchool;

  @IsOptional()
  @IsString()
  castTime?: string;

  @IsOptional()
  @IsString()
  range?: string;

  @IsOptional()
  @IsString()
  duration?: string;

  @IsOptional()
  @IsString()
  components?: string;

  @IsOptional()
  @IsBoolean()
  concentration?: boolean;

  @IsOptional()
  @IsBoolean()
  ritual?: boolean;

  @IsOptional()
  @IsEnum(SpellType)
  attackType?: SpellType;

  @IsOptional()
  @IsEnum(SaveAbility)
  saveAbility?: SaveAbility;

  @IsOptional()
  @IsInt()
  @Min(0)
  @Max(99)
  dcOverride?: number;

  @IsOptional()
  @IsEnum(AttackType)
  atkType?: AttackType;

  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => DmgDiceDto)
  dmgDice?: DmgDiceDto[];

  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => UpcastDiceDto)
  upcastDice?: UpcastDiceDto[];

  // Cantrip-specific fields
  @IsOptional()
  @IsEnum(DiceType)
  cantripDie?: DiceType;

  @IsOptional()
  @IsEnum(OutputType)
  cantripType?: OutputType;

  @IsOptional()
  @IsBoolean()
  cantripAddMod?: boolean;

  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CantripScalingDto)
  cantripScaling?: CantripScalingDto[];

  // Multi-projectile fields
  @IsOptional()
  @IsBoolean()
  multiProj?: boolean;

  @IsOptional()
  @IsInt()
  @Min(1)
  projBase?: number;

  @IsOptional()
  @IsBoolean()
  projUpcast?: boolean;

  @IsOptional()
  @IsInt()
  @Min(1)
  projUpcastEveryN?: number;

  @IsOptional()
  @IsInt()
  @Min(1)
  projUpcastAbove?: number;

  @IsOptional()
  @IsString()
  @MaxLength(4000)
  notes?: string;
}
