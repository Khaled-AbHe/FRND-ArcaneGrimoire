import { IsInt, Min, IsBoolean, IsOptional, IsString } from 'class-validator';

export class DmgDiceDto {
  @IsInt()
  @Min(0)
  count: number;

  /** e.g. "d6", "d8", "d10" — use "d0" when the row is flat-bonus only */
  @IsString()
  die: string;

  /** Whether to add the spellcasting modifier to this die row */
  @IsBoolean()
  addMod: boolean;

  /** Hardcoded flat bonus added to this die row (e.g. +40 for Disintegrate) */
  @IsOptional()
  @IsInt()
  flatBonus?: number;

  /** Damage type label e.g. "Fire", "Radiant" */
  @IsString()
  type: string;
}
