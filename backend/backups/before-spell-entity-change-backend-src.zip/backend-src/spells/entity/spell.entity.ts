import {
  Entity,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  PrimaryGeneratedColumn,
  ManyToOne,
} from 'typeorm';
import { User } from '../../users/entities/user.entity';
import { MagicSchool } from '../enums/magic-school.enum';
import { SaveAbility } from '../enums/save-ability.enum';
import { DiceType } from '../enums/dice-type.enum';
import { OutputType } from '../enums/output-type.enum';
import { SpellType } from '../enums/spell-type.enum';
import { AttackType } from '../enums/attack-type.enum';

@Entity('spells')
export class Spell {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @Column({ default: '1' })
  level: string;

  @Column({ nullable: true })
  school: MagicSchool;

  @Column({ nullable: true })
  castTime: string;

  @Column({ nullable: true })
  range: string;

  @Column({ nullable: true })
  duration: string;

  @Column({ nullable: true })
  components: string;

  @Column({ default: false })
  concentration: boolean;

  @Column({ default: false })
  ritual: boolean;

  @Column({ default: SpellType.None })
  attackType: SpellType;

  @Column({ nullable: true })
  saveAbility: SaveAbility;

  @Column({ nullable: true })
  dcOverride: number;

  @Column({ nullable: true })
  atkType?: AttackType;

  @Column({ type: 'simple-json', default: '[]' })
  dmgDice: object[];

  @Column({ type: 'simple-json', default: '[]' })
  upcastDice: object[];

  @Column({ nullable: true })
  cantripDie: DiceType;

  @Column({ nullable: true })
  cantripType: OutputType;

  @Column({ default: false })
  cantripAddMod: boolean;

  @Column({ type: 'simple-json', nullable: true })
  cantripScaling: object[];

  @Column({ default: false })
  multiProj: boolean;

  @Column({ nullable: true })
  projBase: number;

  @Column({ default: false })
  projUpcast: boolean;

  @Column({ nullable: true })
  projUpcastEveryN: number;

  @Column({ nullable: true })
  projUpcastAbove: number;

  @Column({ nullable: true, type: 'text' })
  notes: string;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  ///////////////////

  @ManyToOne(() => User, (user) => user.spells)
  user: User;
}
