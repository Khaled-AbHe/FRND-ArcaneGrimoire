export enum UserType {
  // Regular access
  BASE = 'Base',

  //Account management
  ADMIN = 'Admin',
}
