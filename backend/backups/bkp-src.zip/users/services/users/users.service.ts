import { Injectable, NotFoundException } from '@nestjs/common';
import { User } from '../../entities/user.entity';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { UserType } from '../../enums/users.enum';

@Injectable()
export class UsersService {
  constructor(@InjectRepository(User) private userRepo: Repository<User>) {}

  async createUser(data: {
    userType: UserType;
    email: string;
    password: string;
  }) {
    return await this.userRepo.save(this.userRepo.create(data));
  }

  async updateUser(userId: number, attrs: Partial<User>) {
    const user = await this.findUserById(userId);
    Object.assign(user, attrs);
    return await this.userRepo.save(user);
  }

  async deleteUserById(userId: number) {
    this.userRepo.delete(await this.findUserById(userId));
  }

  async findAllUsers() {
    return await this.userRepo.find();
  }

  async findUserById(userId: number) {
    const user = await this.userRepo.findOneBy({ userId });

    if (!user) {
      throw new NotFoundException("User doesn't exist.");
    }

    return user;
  }

  async findUserByEmail(email: string) {
    return await this.userRepo.findOneBy({ email });
  }

  // Used for current user logic
  async findOneUser(userId: number) {
    return await this.userRepo.findOneBy({ userId });
  }
}
