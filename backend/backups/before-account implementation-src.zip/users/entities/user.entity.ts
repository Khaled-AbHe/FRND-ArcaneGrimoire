import {
  Column,
  Entity,
  OneToMany,
  PrimaryGeneratedColumn,
  TableInheritance,
} from 'typeorm';
import { Exclude } from 'class-transformer';
import { UserType } from '../enums/users.enum';
import { Character } from 'src/src/characters/entity/character.entity';

@Entity()
@TableInheritance({ column: { type: 'varchar', name: 'type' } }) // combines admin and client into the user table
export class User {
  @PrimaryGeneratedColumn()
  userId: number;

  @Column()
  userType: UserType;

  @Column()
  username: string;

  @Column()
  email: string;

  @Exclude() // this tells interceptors that password should be hidden
  @Column()
  password: string;

  ///////////////////

  @OneToMany(() => Character, (char) => char.user)
  characters: Character[];
}
