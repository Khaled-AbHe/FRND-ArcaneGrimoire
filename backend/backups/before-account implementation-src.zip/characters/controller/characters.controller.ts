import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  ParseIntPipe,
  Post,
  Put,
} from '@nestjs/common';
import { CreateCharacterDto } from '../dtos/create-character.dto';
import { DuplicateCharacterDto } from '../dtos/duplicate-character.dto';
import { UpdateCharacterDto } from '../dtos/update-character.dto';
import { CharactersService } from '../service/characters.service';

@Controller('characters')
export class CharactersController {
  constructor(private readonly charactersService: CharactersService) {}

  // GET /api/characters — list all characters
  @Get()
  findAll() {
    return this.charactersService.findAll();
  }

  // GET /api/characters/:id — get one character with all its data
  @Get('/:id')
  findOne(@Param('id', ParseIntPipe) id: number) {
    return this.charactersService.findCharacterById(id);
  }

  // GET /api/characters/:id/computed — spell save DC, attack bonus, cantrip tier
  @Get('/:id/computed')
  getComputedStats(@Param('id', ParseIntPipe) id: number) {
    return this.charactersService.getComputedStats(id);
  }

  // POST /api/characters/create — create a new character
  @Post('/create')
  create(@Body() dto: CreateCharacterDto) {
    return this.charactersService.create(dto);
  }

  // PUT /api/characters/update/:id — partial update (name, levels, pact, globals, prepared)
  @Put('/update/:id')
  update(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateCharacterDto,
  ) {
    return this.charactersService.update(id, dto);
  }

  // DELETE /api/characters/delete/:id — delete a character
  @Delete('/delete/:id')
  @HttpCode(HttpStatus.NO_CONTENT)
  remove(@Param('id', ParseIntPipe) id: number) {
    return this.charactersService.remove(id);
  }

  // POST /api/characters/:id/duplicate — duplicate a character, backend assigns new ID
  @Post('/:id/duplicate')
  duplicate(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: DuplicateCharacterDto,
  ) {
    return this.charactersService.duplicate(id, dto.name);
  }

  // POST /api/characters/:id/rest/short — restore pact slots only
  @Post('/:id/rest/short')
  shortRest(@Param('id', ParseIntPipe) id: number) {
    return this.charactersService.shortRest(id);
  }

  // POST /api/characters/:id/rest/long — restore all slots and reset arcanum
  @Post('/:id/rest/long')
  longRest(@Param('id', ParseIntPipe) id: number) {
    return this.charactersService.longRest(id);
  }
}
