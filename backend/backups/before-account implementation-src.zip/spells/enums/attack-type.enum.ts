export enum AttackType {
  None = 'none',
  Attack = 'attack',
  Save = 'save',
}
