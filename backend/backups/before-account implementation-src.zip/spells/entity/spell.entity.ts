import {
  Entity,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  PrimaryGeneratedColumn,
} from 'typeorm';

@Entity('spells')
export class Spell {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @Column({ default: '1' })
  level: string; // "cantrip" | "1"-"9" (or up to "12" for high magic)

  @Column({ nullable: true })
  school: string;

  @Column({ nullable: true })
  castTime: string;

  @Column({ nullable: true })
  range: string;

  @Column({ nullable: true })
  duration: string;

  // V, S, M components string e.g. "V, S, M (bat guano)"
  @Column({ nullable: true })
  components: string;

  @Column({ default: false })
  concentration: boolean;

  @Column({ default: false })
  ritual: boolean;

  @Column({ default: 'none' })
  attackType: string; // "none" | "attack" | "save"

  @Column({ nullable: true })
  saveAbility: string;

  @Column({ nullable: true })
  dcOverride: number;

  @Column({ nullable: true })
  atkType: string;

  // Damage dice stored as JSON array
  @Column({ type: 'simple-json', default: '[]' })
  dmgDice: object[];

  // Upcast dice stored as JSON array
  @Column({ type: 'simple-json', default: '[]' })
  upcastDice: object[];

  // Cantrip-specific fields
  @Column({ nullable: true })
  cantripDie: string;

  @Column({ nullable: true })
  cantripType: string;

  @Column({ default: false })
  cantripAddMod: boolean;

  @Column({ type: 'simple-json', nullable: true })
  cantripScaling: object[];

  @Column({ default: false })
  multiProj: boolean;

  @Column({ nullable: true })
  projBase: number;

  @Column({ default: false })
  projUpcast: boolean;

  @Column({ nullable: true })
  projUpcastEveryN: number;

  @Column({ nullable: true })
  projUpcastAbove: number;

  @Column({ nullable: true, type: 'text' })
  notes: string;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
