import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CreateSpellDto } from '../dtos/create-spell.dto';
import { UpdateSpellDto } from '../dtos/update-spell.dto';
import { ReplaceAllSpellsDto } from '../dtos/replace-all-spells.dto';
import { SpellTemplateDto } from '../dtos/spell-template.dto';
import { Spell } from '../entity/spell.entity';
import {
  FULL_CASTER_SLOTS,
  HALF_CASTER_SLOTS,
  WARLOCK_PACT,
  ARCANUM_UNLOCKS,
} from '../../constants/game.constants';

/** Shape returned by the template endpoint */
export interface TemplateResult {
  casterType: string;
  charLevel: number;
  /** Level rows ready to drop into character.levels */
  levels: Array<{
    id: string;
    label: string;
    total: number;
    used: number;
  }>;
  /** Pact block for warlock — null for other caster types */
  pact: {
    enabled: boolean;
    slots: number;
    slotLevel: number;
    used: number;
    arcana: Array<{ level: number; spellId: null; used: boolean }>;
  } | null;
}

@Injectable()
export class SpellsService {
  constructor(@InjectRepository(Spell) private spellsRepo: Repository<Spell>) {}

  async findAll(): Promise<Spell[]> {
    return await this.spellsRepo
      .createQueryBuilder('item')
      .orderBy(
        `CASE 
          WHEN item.level = 'cantrip' THEN 0 
          ELSE CAST(item.level AS INTEGER) 
        END`,
        'ASC',
      )
      .getMany();
  }

  async findSpellById(id: number): Promise<Spell> {
    const spell = await this.spellsRepo.findOneBy({ id });
    if (!spell) {
      throw new NotFoundException(`Spell ${id} not found`);
    }
    return spell;
  }

  async create(dto: CreateSpellDto): Promise<Spell> {
    return await this.spellsRepo.save(this.spellsRepo.create(dto));
  }

  async update(id: number, dto: UpdateSpellDto): Promise<Spell> {
    const spell = await this.findSpellById(id);
    Object.assign(spell, dto);
    return await this.spellsRepo.save(spell);
  }

  async remove(id: number): Promise<void> {
    const spell = await this.findSpellById(id);
    await this.spellsRepo.remove(spell);
  }

  async replaceAll(dto: ReplaceAllSpellsDto): Promise<Spell[]> {
    await this.spellsRepo.clear();
    const entities = await Promise.all(
      dto.spells.map((s) => this.spellsRepo.create(s)),
    );
    return await this.spellsRepo.save(entities);
  }

  // ── Template generation ─────────────────────────────────────────────────────

  /**
   * Returns the correct spell slot rows (and pact block for warlocks) for
   * the given caster type and character level.
   * The frontend can apply this directly to character.levels / character.pact.
   */
  getTemplate(dto: SpellTemplateDto): TemplateResult {
    const { casterType, charLevel } = dto;
    const rowIndex = charLevel - 1; // tables are 0-indexed

    if (casterType === 'warlock') {
      return this.buildWarlockTemplate(charLevel, rowIndex);
    }

    const table = casterType === 'full' ? FULL_CASTER_SLOTS : HALF_CASTER_SLOTS;
    const slotRow = table[rowIndex] ?? table[table.length - 1];

    const levels = slotRow
      .map((total, i) => ({
        id: `level_${i + 1}`,
        label: `Level ${i + 1}`,
        total,
        used: 0,
      }))
      .filter((row) => row.total > 0);

    return { casterType, charLevel, levels, pact: null };
  }

  private buildWarlockTemplate(
    charLevel: number,
    rowIndex: number,
  ): TemplateResult {
    const pactRow =
      WARLOCK_PACT[rowIndex] ?? WARLOCK_PACT[WARLOCK_PACT.length - 1];

    // Arcanum slots unlocked at this character level
    const arcana = ARCANUM_UNLOCKS.filter((u) => charLevel >= u.charLevel).map(
      (u) => ({
        level: u.spellLevel,
        spellId: null,
        used: false,
      }),
    );

    return {
      casterType: 'warlock',
      charLevel,
      // Warlocks have no regular spell-level rows — only pact slots
      levels: [],
      pact: {
        enabled: true,
        slots: pactRow.slots,
        slotLevel: pactRow.slotLevel,
        used: 0,
        arcana,
      },
    };
  }
}
