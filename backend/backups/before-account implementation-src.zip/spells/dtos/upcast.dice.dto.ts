import { IsInt, Min, IsString, Max, IsOptional } from "class-validator";

export class UpcastDiceDto {
    @IsInt()
    @Min(0)
    count: number;
  
    /** e.g. "d6" — use "d0" for flat-bonus-only upcast rows (e.g. False Life +5/slot) */
    @IsString()
    die: string;
  
    /** Gain this many dice per N slot levels above base */
    @IsInt()
    @Min(1)
    everyN: number;
  
    /** The base slot level the upcast is measured from */
    @IsInt()
    @Min(1)
    @Max(12)
    aboveLevel: number;
  
    @IsString()
    type: string;
  
    /** Flat bonus added per upcast step (e.g. +5 HP for False Life) */
    @IsOptional()
    @IsInt()
    flatBonus?: number;
  }