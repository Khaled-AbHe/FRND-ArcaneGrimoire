import { IsInt, Min, Max } from "class-validator";

export class CantripScalingDto {
    /** Character level at which this tier activates */
    @IsInt()
    @Min(1)
    @Max(30)
    threshold: number;
  
    /** Number of dice at this tier */
    @IsInt()
    @Min(1)
    count: number;
  }