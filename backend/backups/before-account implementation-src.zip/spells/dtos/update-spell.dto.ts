
import { Type } from 'class-transformer';
import {
  IsArray,
  IsBoolean,
  IsEnum,
  IsInt,
  IsOptional,
  IsString,
  Max,
  MaxLength,
  Min,
  MinLength,
  ValidateNested,
} from 'class-validator';
import { AttackType } from '../enums/attack-type.enum';
import { SpellLevel } from '../enums/spell-level.enum';
import { CantripScalingDto } from './cantrip-scaling.dto';
import { DmgDiceDto } from './dmg-dice.dto';
import { UpcastDiceDto } from './upcast.dice.dto';

/**
 * All fields optional on update.
 * PartialType re-applies every validator from CreateSpellDto
 * while marking each property @IsOptional().
 */
export class UpdateSpellDto {
  @IsString()
  @MinLength(1)
  @MaxLength(128)
  name: string;

  @IsOptional()
  @IsEnum(SpellLevel)
  level?: SpellLevel;

  @IsOptional()
  @IsString()
  school?: string;

  @IsOptional()
  @IsString()
  castTime?: string;

  @IsOptional()
  @IsString()
  range?: string;

  @IsOptional()
  @IsString()
  duration?: string;

  @IsOptional()
  @IsString()
  components?: string;

  @IsOptional()
  @IsBoolean()
  concentration?: boolean;

  @IsOptional()
  @IsBoolean()
  ritual?: boolean;

  @IsOptional()
  @IsEnum(AttackType)
  attackType?: AttackType;

  @IsOptional()
  @IsString()
  saveAbility?: string;

  @IsOptional()
  @IsInt()
  @Min(0)
  @Max(99)
  dcOverride?: number;

  @IsOptional()
  @IsString()
  atkType?: string;

  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => DmgDiceDto)
  dmgDice?: DmgDiceDto[];

  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => UpcastDiceDto)
  upcastDice?: UpcastDiceDto[];

  // Cantrip-specific fields
  @IsOptional()
  @IsString()
  cantripDie?: string;

  @IsOptional()
  @IsString()
  cantripType?: string;

  @IsOptional()
  @IsBoolean()
  cantripAddMod?: boolean;

  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CantripScalingDto)
  cantripScaling?: CantripScalingDto[];

  // Multi-projectile fields
  @IsOptional()
  @IsBoolean()
  multiProj?: boolean;

  @IsOptional()
  @IsInt()
  @Min(1)
  projBase?: number;

  @IsOptional()
  @IsBoolean()
  projUpcast?: boolean;

  @IsOptional()
  @IsInt()
  @Min(1)
  projUpcastEveryN?: number;

  @IsOptional()
  @IsInt()
  @Min(1)
  projUpcastAbove?: number;

  @IsOptional()
  @IsString()
  @MaxLength(4000)
  notes?: string;
}
