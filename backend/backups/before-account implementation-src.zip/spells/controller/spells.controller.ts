import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  ParseIntPipe,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { CreateSpellDto } from '../dtos/create-spell.dto';
import { UpdateSpellDto } from '../dtos/update-spell.dto';
import { ReplaceAllSpellsDto } from '../dtos/replace-all-spells.dto';
import { SpellTemplateDto } from '../dtos/spell-template.dto';
import { SpellsService } from '../service/spells.service';

@Controller('spells')
export class SpellsController {
  constructor(private readonly spellsService: SpellsService) {}

  // GET /api/spells — get entire shared spellbook
  @Get()
  findAll() {
    return this.spellsService.findAll();
  }

  // GET /api/spells/:id
  @Get('/:id')
  findOne(@Param('id', ParseIntPipe) id: number) {
    return this.spellsService.findSpellById(id);
  }

  // POST /api/spells/create — add a spell
  @Post('/create')
  create(@Body() dto: CreateSpellDto) {
    return this.spellsService.create(dto);
  }

  // PUT /api/spells/update/:id — update a spell
  @Put('/update/:id')
  update(@Param('id', ParseIntPipe) id: number, @Body() dto: UpdateSpellDto) {
    return this.spellsService.update(id, dto);
  }

  // DELETE /api/spells/delete/:id
  @Delete('/delete/:id')
  @HttpCode(HttpStatus.NO_CONTENT)
  remove(@Param('id', ParseIntPipe) id: number) {
    return this.spellsService.remove(id);
  }

  // POST /api/spells/replaceAll — sync the whole spellbook at once
  @Post('/replaceAll')
  replaceAll(@Body() dto: ReplaceAllSpellsDto) {
    return this.spellsService.replaceAll(dto);
  }

  // POST /api/spells/template — get slot rows + pact block for a caster type & level
  @Post('/template')
  getTemplate(@Body() dto: SpellTemplateDto) {
    return this.spellsService.getTemplate(dto);
  }
}
