import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SpellsController } from './controller/spells.controller';
import { Spell } from './entity/spell.entity';
import { SpellsService } from './service/spells.service';

@Module({
  imports: [TypeOrmModule.forFeature([Spell])],
  providers: [SpellsService],
  controllers: [SpellsController],
})
export class SpellsModule {}
