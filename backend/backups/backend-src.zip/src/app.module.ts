import { Module } from '@nestjs/common';
import { SpellsModule } from './spells/spells.module';
import { CharactersModule } from './characters/characters.module';
import { TypeOrmModule } from '@nestjs/typeorm';

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'sqlite',
      database: 'spellslot.sqlite',
      autoLoadEntities: true,
      synchronize: true, // Usually, you keep this at False so you dont mess with an established database
      dropSchema: false, // This clears the db each time you run it if set to 'true'. !!!! RUNNING YOUR PROGAM WITH 'npm run start:dev' IS NOT RECOMMENDED WITH THIS ON!!!
    }),
    SpellsModule,
    CharactersModule,
  ],
})
export class AppModule {}
