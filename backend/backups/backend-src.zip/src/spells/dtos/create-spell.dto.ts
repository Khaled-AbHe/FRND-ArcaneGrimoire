import {
  IsString,
  IsOptional,
  IsBoolean,
  IsNumber,
  IsArray,
  IsEnum,
  IsInt,
  Min,
  Max,
  ValidateNested,
  MinLength,
  MaxLength,
} from 'class-validator';
import { Type } from 'class-transformer';

// ── Allowed spell level values ────────────────────────────────────────────────
export enum SpellLevel {
  Cantrip = 'cantrip',
  One = '1',
  Two = '2',
  Three = '3',
  Four = '4',
  Five = '5',
  Six = '6',
  Seven = '7',
  Eight = '8',
  Nine = '9',
  // High-magic homebrew levels
  Ten = '10',
  Eleven = '11',
  Twelve = '12',
}

// ── Attack type ───────────────────────────────────────────────────────────────
export enum AttackType {
  None = 'none',
  Attack = 'attack',
  Save = 'save',
}

// ── Nested: one damage die row ────────────────────────────────────────────────
export class DmgDiceDto {
  @IsInt()
  @Min(0)
  count: number;

  /** e.g. "d6", "d8", "d10" — use "d0" when the row is flat-bonus only */
  @IsString()
  die: string;

  /** Whether to add the spellcasting modifier to this die row */
  @IsBoolean()
  addMod: boolean;

  /** Hardcoded flat bonus added to this die row (e.g. +40 for Disintegrate) */
  @IsOptional()
  @IsInt()
  flatBonus?: number;

  /** Damage type label e.g. "Fire", "Radiant" */
  @IsString()
  type: string;
}

// ── Nested: one upcast die row ────────────────────────────────────────────────
export class UpcastDiceDto {
  @IsInt()
  @Min(0)
  count: number;

  /** e.g. "d6" — use "d0" for flat-bonus-only upcast rows (e.g. False Life +5/slot) */
  @IsString()
  die: string;

  /** Gain this many dice per N slot levels above base */
  @IsInt()
  @Min(1)
  everyN: number;

  /** The base slot level the upcast is measured from */
  @IsInt()
  @Min(1)
  @Max(12)
  aboveLevel: number;

  @IsString()
  type: string;

  /** Flat bonus added per upcast step (e.g. +5 HP for False Life) */
  @IsOptional()
  @IsInt()
  flatBonus?: number;
}

// ── Nested: one cantrip scaling tier ─────────────────────────────────────────
export class CantripScalingDto {
  /** Character level at which this tier activates */
  @IsInt()
  @Min(1)
  @Max(30)
  threshold: number;

  /** Number of dice at this tier */
  @IsInt()
  @Min(1)
  count: number;
}

// ── Main DTO ──────────────────────────────────────────────────────────────────
export class CreateSpellDto {
  @IsString()
  @MinLength(1)
  @MaxLength(128)
  name: string;

  @IsOptional()
  @IsEnum(SpellLevel)
  level?: SpellLevel;

  @IsOptional()
  @IsString()
  school?: string;

  @IsOptional()
  @IsString()
  castTime?: string;

  @IsOptional()
  @IsString()
  range?: string;

  @IsOptional()
  @IsString()
  duration?: string;

  @IsOptional()
  @IsString()
  components?: string;

  @IsOptional()
  @IsBoolean()
  concentration?: boolean;

  @IsOptional()
  @IsBoolean()
  ritual?: boolean;

  @IsOptional()
  @IsEnum(AttackType)
  attackType?: AttackType;

  @IsOptional()
  @IsString()
  saveAbility?: string;

  @IsOptional()
  @IsInt()
  @Min(0)
  @Max(99)
  dcOverride?: number;

  @IsOptional()
  @IsString()
  atkType?: string;

  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => DmgDiceDto)
  dmgDice?: DmgDiceDto[];

  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => UpcastDiceDto)
  upcastDice?: UpcastDiceDto[];

  // Cantrip-specific fields
  @IsOptional()
  @IsString()
  cantripDie?: string;

  @IsOptional()
  @IsString()
  cantripType?: string;

  @IsOptional()
  @IsBoolean()
  cantripAddMod?: boolean;

  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CantripScalingDto)
  cantripScaling?: CantripScalingDto[];

  // Multi-projectile fields
  @IsOptional()
  @IsBoolean()
  multiProj?: boolean;

  @IsOptional()
  @IsInt()
  @Min(1)
  projBase?: number;

  @IsOptional()
  @IsBoolean()
  projUpcast?: boolean;

  @IsOptional()
  @IsInt()
  @Min(1)
  projUpcastEveryN?: number;

  @IsOptional()
  @IsInt()
  @Min(1)
  projUpcastAbove?: number;

  @IsOptional()
  @IsString()
  @MaxLength(4000)
  notes?: string;
}
