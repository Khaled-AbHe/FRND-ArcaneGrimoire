import {
  Entity,
  PrimaryColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  PrimaryGeneratedColumn,
} from 'typeorm';

@Entity('characters')
export class Character {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  // Stored as JSON blobs — mirrors exactly what the React app already uses
  @Column({ type: 'simple-json', default: '[]' })
  levels: object[];

  @Column({ type: 'simple-json', default: '[]' })
  prepared: string[];

  @Column({ type: 'simple-json', default: '{}' })
  pact: object;

  @Column({ type: 'simple-json', default: '{}' })
  globals: object;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
