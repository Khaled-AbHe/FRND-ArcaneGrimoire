import { PartialType } from '@nestjs/mapped-types';
import { CreateCharacterDto } from './create-character.dto';
import {
  IsArray,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  MaxLength,
  MinLength,
  ValidateNested,
} from 'class-validator';
import { Type } from 'class-transformer';
import { LevelDto, PactDto, GlobalsDto } from './nested.dto';

/**
 * All fields are optional on update.
 * The frontend debounces auto-saves and sends only changed fields.
 * PartialType re-applies all validators from CreateCharacterDto
 * while marking every property @IsOptional().
 */
export class UpdateCharacterDto {
  @IsOptional()
  @IsString()
  @MinLength(1)
  @MaxLength(64)
  name: string;

  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => LevelDto)
  levels?: LevelDto[];

  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  prepared?: string[];

  @IsOptional()
  @ValidateNested()
  @Type(() => PactDto)
  pact?: PactDto;

  @IsOptional()
  @ValidateNested()
  @Type(() => GlobalsDto)
  globals?: GlobalsDto;
}
