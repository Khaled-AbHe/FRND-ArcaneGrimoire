import {
  IsString,
  IsBoolean,
  IsNumber,
  IsArray,
  IsOptional,
  ValidateNested,
  Min,
  Max,
  IsInt,
} from 'class-validator';
import { Type } from 'class-transformer';

// ── Arcanum slot linked to a spell ────────────────────────────────────────────
export class ArcanaDto {
  /** The slot level this arcanum occupies (6–9) */
  @IsInt()
  @Min(6)
  @Max(9)
  level: number;

  /** Spell ID from the shared spellbook, or null if unlinked */
  @IsOptional()
  @IsString()
  spellId: string | null;

  /** Whether this arcanum has been used this long rest */
  @IsBoolean()
  used: boolean;
}

// ── One spell-level row (e.g. Level 3 — 4 total, 2 used) ─────────────────────
export class LevelDto {
  /** Frontend-assigned ID string, e.g. "level_3" */
  @IsString()
  id: string;

  /** Display label, e.g. "Level 3" or "Cantrip" */
  @IsString()
  label: string;

  /** Total slots available at this level (0–12) */
  @IsInt()
  @Min(0)
  @Max(12)
  total: number;

  /** Slots currently expended (0–total) */
  @IsInt()
  @Min(0)
  @Max(12)
  used: number;
}

// ── Pact Magic block ──────────────────────────────────────────────────────────
export class PactDto {
  @IsBoolean()
  enabled: boolean;

  /** Number of pact slots (1–5 per RAW, allow up to 12 for homebrew) */
  @IsInt()
  @Min(0)
  @Max(12)
  slots: number;

  /** The level all pact slots operate at (1–9) */
  @IsInt()
  @Min(1)
  @Max(9)
  slotLevel: number;

  /** Pact slots currently expended */
  @IsInt()
  @Min(0)
  @Max(12)
  used: number;

  /** Mystic Arcanum entries (one per unlocked arcanum level) */
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => ArcanaDto)
  arcana: ArcanaDto[];
}

// ── Per-character global settings ─────────────────────────────────────────────
export class GlobalsDto {
  /** Spellcasting ability modifier (−5 to +10 covers all realistic cases) */
  @IsInt()
  @Min(-5)
  @Max(10)
  mod: number;

  /** Proficiency bonus (2–6 covers levels 1–20) */
  @IsInt()
  @Min(2)
  @Max(6)
  prof: number;

  /** Character level used for cantrip scaling (1–20) */
  @IsInt()
  @Min(1)
  @Max(20)
  charLevel: number;

  /** Enables spell levels 10–12 (homebrew High Magic rule) */
  @IsBoolean()
  highMagic: boolean;
}
